$( document ).ready(function(){
    data = $("#years>li").attr("data-toggle");
    $("#years>li").on('click', function() {
        if (data == 1) {
        $(this).find(".first").css({
            "top":"14px",
            "right":"-1px"
        });
        $(this).prevAll().find(".first").css({
            "top":"-30px"
        });
        $(this).nextAll().find(".first").css({
            "top":"-30px"
        });
        $(this).css({
            "width":"50px",
            "height":"50px",
            "top":"-21px"
        });
        $(this).nextAll().css({
            "width":"30px",
            "height":"30px",
            "top":"-14px"
        });
        $(this).prevAll().css({
            "width":"30px",
            "height":"30px",
            "top":"-14px"
        });
    }
    });
});